This directory contains modified Russian (Cyrillic) Keyboard Layout OSX (similar with Russian Keyboard Layout on Windows PC).

*******************************************************************************
* How to install                                                              *
*******************************************************************************

1. Copy files to "~/Library/Keyboard Layouts" directory.

If this directory doesn't exists create it.


2. After that you need activate Keyboard Input Source.

* Open: System Preferences -> Keyboard -> Input Sources
* Press +, select Others and "Russian - Windows", press "Add"

3. Change Keyboard Hotkey to switch between Input Sources.

* Open: System Preferences -> Keyboard -> Shortcuts
* Select "Input Sources"
* Check "Select the previous input source - Command (⌘) + Space"

